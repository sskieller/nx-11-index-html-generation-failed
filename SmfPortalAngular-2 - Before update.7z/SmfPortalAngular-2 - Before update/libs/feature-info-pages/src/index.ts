export * from './lib/feature-info-pages.module';
