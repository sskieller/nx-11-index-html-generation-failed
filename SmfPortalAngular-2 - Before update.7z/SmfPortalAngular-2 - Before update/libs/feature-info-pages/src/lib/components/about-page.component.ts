import { Component, ChangeDetectionStrategy } from '@angular/core';

@Component({
  selector: 'app-about-page-component',
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="rdp-content">
      <div class="column-container">
        <div class="left-column">
          <div class="page-content">
            <h1>About RDP</h1>
          </div>
        </div>
      </div>
    </div>
  `,
})
export class AboutPageComponent {}
