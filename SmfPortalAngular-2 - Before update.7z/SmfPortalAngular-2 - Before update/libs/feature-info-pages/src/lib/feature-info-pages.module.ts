import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FeatureInfoPagesRoutingModule } from './feature-info-pages.routing';
import { AboutPageComponent } from './components/about-page.component';

const components: any[] = [AboutPageComponent];

const imports: any[] = [FeatureInfoPagesRoutingModule];

@NgModule({
  imports: [CommonModule, imports],
  declarations: [components],
})
export class FeatureInfoPagesModule {}
