$AffectedAppsObj = Invoke-Expression 'npm run affected:apps -- --base=origin/master --head=HEAD --plain';
$AffectedAppsString = $AffectedAppsObj[4];

# If AffectedAppsString not produced, tag all apps for build
if ($AffectedAppsString -eq "") {
  Write-Host "No affected apps. Tagging with all apps.";
  $AffectedAppsObj = Invoke-Expression 'npm run affected:apps -- --all --plain';
  $AffectedAppsString = $AffectedAppsObj[4];
}

# Else, tag only affected apps for build
"Affected apps: $AffectedAppsString";
New-Item -Path "./dist" -Name "affected-apps.txt" -ItemType "file" -Value "$AffectedAppsString";
