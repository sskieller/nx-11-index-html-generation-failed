class Environment {
  public production: boolean;
  constructor() {
    this.production = true;
  }
}

export const environmentConfig = new Environment();
