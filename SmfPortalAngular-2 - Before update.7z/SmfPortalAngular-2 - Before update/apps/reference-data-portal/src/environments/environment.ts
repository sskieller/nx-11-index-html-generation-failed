class Environment {
  public production: boolean;
  constructor() {
    this.production = false;
  }
}

export const environmentConfig = new Environment();
