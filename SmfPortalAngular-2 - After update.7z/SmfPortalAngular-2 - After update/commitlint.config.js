module.exports = {
  extends: ['@commitlint/config-conventional'],
  rules: {
    'header-max-length': [2, 'always', 120],
    'header-min-length': [2, 'always', 10],
    'subject-case': [
      2,
      'always',
      [
        'lower-case', // default
        'upper-case', // UPPERCASE
        'camel-case', // camelCase
        'pascal-case', // PascalCase
        'sentence-case', // Sentence case
        'start-case', // Start Case
      ],
    ],
  },
};
