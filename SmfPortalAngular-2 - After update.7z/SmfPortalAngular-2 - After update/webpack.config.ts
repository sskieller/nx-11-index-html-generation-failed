const webpackCommonConfig = require('./webpack.common.config');

module.exports = {
  entry: {
    app: './apps/reference-data-portal/src/main.ts',
  },
};
