import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { QuicklinkModule, QuicklinkStrategy } from 'ngx-quicklink';

import { ContentRoutes } from './content-layout.routes';

@NgModule({
  imports: [
    QuicklinkModule,
    // https://www.npmjs.com/package/ngx-quicklink
    RouterModule.forRoot(ContentRoutes, {
    preloadingStrategy: QuicklinkStrategy,
    enableTracing: false,
    initialNavigation: 'enabled',
    useHash: true,
    relativeLinkResolution: 'legacy'
}),
  ],
  exports: [RouterModule],
})
export class AppRoutingModule {}
