import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule } from '@angular/common/http';
import { FlexLayoutModule } from '@angular/flex-layout';

// #region NGXS IMPORTS
import { NgxsModule } from '@ngxs/store';
import { NgxsRouterPluginModule } from '@ngxs/router-plugin';
import { NgxsDispatchPluginModule } from '@ngxs-labs/dispatch-decorator';
import { NgxsFormPluginModule } from '@ngxs/form-plugin';
import { NgxsSelectSnapshotModule } from '@ngxs-labs/select-snapshot';
import { NgxsStoragePluginModule } from '@ngxs/storage-plugin';
import { NgxsLoggerPluginModule } from '@ngxs/logger-plugin';
// #endregion

import { AppRoutingModule } from './app.routing';
import { AppComponent } from './app.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { environmentConfig } from '../environments/environment';

export const declarationsList = [AppComponent];

export const angularImports = [
  // Angular
  BrowserModule,
  HttpClientModule,
  BrowserAnimationsModule,
  FlexLayoutModule,
  FormsModule,
  ReactiveFormsModule,
  AppRoutingModule,
];

export const ngxsImports = [
  // NGXS
  NgxsModule.forRoot([], { developmentMode: !environmentConfig.production }),
  NgxsSelectSnapshotModule.forRoot(),
  NgxsFormPluginModule.forRoot(),
  NgxsLoggerPluginModule.forRoot(),
  NgxsRouterPluginModule.forRoot(),
  NgxsStoragePluginModule.forRoot(),
  NgxsDispatchPluginModule.forRoot(),

];


@NgModule({
  declarations: [AppComponent, declarationsList],
  imports: [angularImports, ngxsImports, NgxsStoragePluginModule.forRoot({ key: ['sharedCacheDataState'] })],
  bootstrap: [AppComponent],
  exports: [],
})
export class AppModule { }
