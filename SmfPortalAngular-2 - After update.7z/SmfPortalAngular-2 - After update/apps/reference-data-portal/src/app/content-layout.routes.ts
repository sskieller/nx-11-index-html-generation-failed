import { Routes } from '@angular/router';



export const ContentRoutes: Routes = [
  {
    // Important not to lazyload
    path: 'login',
  },

];
