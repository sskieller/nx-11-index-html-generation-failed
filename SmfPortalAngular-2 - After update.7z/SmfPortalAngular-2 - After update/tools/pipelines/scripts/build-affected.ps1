# Save object of running on master branch producing plain string
$AffectedAppsObj = Invoke-Expression 'npm run affected:apps -- --base=origin/master --head=HEAD --plain';
$AffectedAppsString = $AffectedAppsObj[4];

# If No affected apps string, run build for all apps
if (!$AffectedAppsString -and $AffectedAppsString -eq "") {
  Write-Host "No affected apps. Building all apps.";
  Invoke-Expression 'npm run affected:build -- --prod --plaing --all';
  return;
}
# Else run for affected apps only
Invoke-Expression 'npm run affected:build -- --base=origin/master --head=HEAD --prod';
