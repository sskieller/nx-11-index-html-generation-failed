module.exports = {
  projects: ['<rootDir>/apps/reference-data-portal', '<rootDir>/libs/feature-info-pages'],
};
